package com.project.together.controller;

import lombok.Data;

@Data
public class AnswerForm {
    private String answer;
}
