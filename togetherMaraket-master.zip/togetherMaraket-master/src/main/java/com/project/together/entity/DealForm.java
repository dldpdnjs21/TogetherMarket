package com.project.together.entity;

public enum DealForm {
    택배거래,직거래,둘다가능
}
