package com.project.together.controller;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BuyForm {
    private String id;
}
