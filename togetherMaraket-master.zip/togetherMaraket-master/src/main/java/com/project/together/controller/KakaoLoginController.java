package com.project.together.controller;

import com.project.together.entity.User;
import com.project.together.repository.UserRepository;
import com.project.together.service.KakaoLoginService;
import com.project.together.service.LoginService;
import com.project.together.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;

@Controller
@Slf4j
@RequiredArgsConstructor
public class KakaoLoginController {

    private final KakaoLoginService kakaoLoginService;

    private final UserService userService;

    private final UserRepository userRepository;
    private final LoginService loginService;

    private final AuthenticationManager authenticationManager;

    private final BCryptPasswordEncoder passwordEncoder;
    /***
     *
     * @param code : 인가코드로 access 토큰 받기 받기
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/login/oauthKakao")
    public String oauthKakao(
            @RequestParam(value = "code", required = false) String code
            , HttpServletRequest request
    ) throws Exception {
        log.info("code : " + code);

        String accessToken = kakaoLoginService.getAccessToken(code);

        log.info("accessToken : " + accessToken);

        HashMap<String, Object> userInfo = kakaoLoginService.getUserInfo(accessToken);
        System.out.println(userInfo);
        //System.out.println(userRepository.findById((String)userInfo.get("email")).isEmpty());

        //loginService.login((String)userInfo.get("email"), (String)userInfo.get("email"));

        if(userRepository.findById((String)userInfo.get("email")).isEmpty()) {

            String encodedPassword = passwordEncoder.encode((String)userInfo.get("email"));//스프링 시큐리티 카카오 적용중

            User user = new User();
            user.setUserId((String)userInfo.get("email"));
            user.setUserPw(encodedPassword);
            user.setUserName((String)userInfo.get("nickname"));
            user.setCreatedAt(LocalDateTime.now());
            user.setRole("ROLE_USER");
            userService.join(user);
            log.info("회원가입 성공");


        }

            Authentication kakaoUsernamePassword = new UsernamePasswordAuthenticationToken((String)userInfo.get("email"),
                    (String)userInfo.get("email"));
            Authentication authentication = authenticationManager.authenticate(kakaoUsernamePassword);
            SecurityContextHolder.getContext().setAuthentication(authentication);



        return "redirect:/";
    }



}
