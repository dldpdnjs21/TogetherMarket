package com.project.together.entity;

public enum Enul {
    가능,불가능
}
