package com.project.together.entity;

public enum ItemStatus {
    SELLING, SOLD
}
